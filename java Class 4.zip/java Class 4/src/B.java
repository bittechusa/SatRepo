
public class B 
{
	static int v=10;
	static String name2;
	
	static String name="shahid";//global variable
	 void m1()
	{
		;
		v=10;
		name2="hgff";
		System.out.println(name);
	}//end of method
	void m2()
	{
		
		int a=20;
		System.out.println(a);
	}
	 int m5()
	{
		int a=5;
		System.out.println(14);
		return a;
	}
	

}
